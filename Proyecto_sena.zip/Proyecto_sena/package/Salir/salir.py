def salir():
    t = str(input("Desea salir:  "))
    print("Para salir escriba si")
    if t == "si":
        print("salida exitosa")
        exit()
    else:
        print("salida errónea")