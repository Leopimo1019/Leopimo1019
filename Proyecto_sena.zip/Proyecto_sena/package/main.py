from Ingresar.Ingresar import ing
from Modificar.Modificar import mod
from Ordenar.Ordenar import Org
from Eliminar.Eliminar import eli, z
from Salir.salir import salir
     
eli(z)