from Ingresar.Ingresar import ing
from Modificar.Modificar import mod
from Eliminar.Eliminar import eli, z
eli(z)
