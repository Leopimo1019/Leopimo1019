from Ingresar.Ingresar import *

def Org(list):
    list.sort()
    print('La lista ordenada es: ', list)
    return list
Org(z)
