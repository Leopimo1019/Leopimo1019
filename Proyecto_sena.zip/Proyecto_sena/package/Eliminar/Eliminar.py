from Ingresar.Ingresar import z
from Salir.salir import salir
def eli(lis):
    eliminar = str(input('Producto a eliminar: '))
    for x in range(len(lis)):
        eliminacion = True
        if eliminar in lis[x]:
            lis.remove(eliminar)
            print("Eliminación exitosa", lis)
            salir()
            exit()
            eliminacion = False
    if eliminacion :
        print("Su producto no está disponible", eliminar)
       
eli(z)